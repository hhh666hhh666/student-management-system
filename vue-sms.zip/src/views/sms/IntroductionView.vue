<template>
    <div>
        <el-card class="content-card">
            <div slot="header">
                <span>欢迎使用学生管理系统</span>
            </div>
            <div>
                这里是学生管理系统的介绍，您可以在这里了解系统功能。
            </div>
        </el-card>
    </div>
</template>

<script>
export default {
    name: 'IntroductionView',
    data() {
        return {};
    }
};
</script>

<style scoped>
.content-card {
    min-height: 300px;
}
</style>
