<template>
    <div class="login-container">
        <div class="login-box">
            <h2 class="login-title">学生管理系统</h2>
            <el-form :model="loginForm" :rules="loginRules" ref="loginForm" class="login-form">
                <el-form-item prop="username">
                    <el-input v-model="loginForm.username" prefix-icon="el-icon-user" placeholder="请输入用户名">
                    </el-input>
                </el-form-item>
                <el-form-item prop="password">
                    <el-input v-model="loginForm.password" prefix-icon="el-icon-lock" type="password"
                        placeholder="请输入密码" @keyup.enter.native="handleLogin">
                    </el-input>
                </el-form-item>
                <el-form-item>
                    <a href="javascript:;" class="forget-pwd" @click="forgetPassword">忘记密码?</a>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" :loading="loading" class="login-button" @click="handleLogin">
                        登录
                    </el-button>
                </el-form-item>
                <el-form-item>
                    <el-button type="success" :loading="registerLoading" class="register-button"
                        @click="handleRegister">
                        注册
                    </el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>

<script>
import request from '@/utils/request'; // 引入封装好的request工具，替代直接使用axios

export default {
    name: 'LoginView',
    data() {
        return {
            loading: false,
            registerLoading: false,
            loginForm: {
                username: '',
                password: ''
            },
            loginRules: {
                username: [
                    { required: true, message: '请输入用户名', trigger: 'blur' },
                    { min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur' }
                ],
                password: [
                    { required: true, message: '请输入密码', trigger: 'blur' },
                    { min: 6, max: 20, message: '长度在 6 到 20 个字符', trigger: 'blur' }
                ]
            }
        };
    },
    methods: {
        handleLogin() {
            this.$refs.loginForm.validate(valid => {
                if (valid) {
                    this.loading = true;

                    // 使用封装好的request工具调用登录API - 使用相对路径
                    request.post('/admin/user/login', this.loginForm)
                        .then(response => {
                            // 直接使用response，因为拦截器已经处理了data的解构
                            // 保存token和用户信息
                            localStorage.setItem('token', response.data.token);
                            localStorage.setItem('userId', response.data.id);
                            localStorage.setItem('username', response.data.username);
                            localStorage.setItem('isLogin', 'true');

                            // 跳转到首页
                            this.$router.push('/');
                            this.$message.success('登录成功');
                        })
                        .catch(error => {
                            console.error('登录失败:', error);

                            // 自己处理登录错误
                            let errorMessage = '登录失败';
                            if (error.response) {
                                errorMessage = `登录失败: ${error.response.data.message || '用户名或密码错误'}`;
                            } else if (error.request) {
                                errorMessage = '登录失败: 服务器无响应，请检查后端服务是否正常运行';
                            } else {
                                errorMessage = `登录失败: ${error.message}`;
                            }
                            this.$message.error(errorMessage);
                        })
                        .finally(() => {
                            this.loading = false;
                        });
                }
            });
        },
        forgetPassword() {
            this.$message.info('请联系系统管理员重置密码');
        },
        handleRegister() {
            this.$refs.loginForm.validate(valid => {
                if (valid) {
                    this.registerLoading = true;

                    request.post('/admin/user/register', this.loginForm)
                        .then(response => {
                            // 保存注册返回的信息
                            localStorage.setItem('token', response.data.token);
                            localStorage.setItem('userId', response.data.id);
                            localStorage.setItem('username', response.data.username);
                            localStorage.setItem('isLogin', 'true');

                            this.$message.success('注册成功');
                            // 注册成功后跳转到首页
                            this.$router.push('/');
                        })
                        .catch(error => {
                            console.error('注册失败:', error);
                            let errorMessage = '注册失败';
                            if (error.response) {
                                errorMessage = `注册失败: ${error.response.data.message || '用户名已存在'}`;
                            } else if (error.request) {
                                errorMessage = '注册失败: 服务器无响应，请检查后端服务是否正常运行';
                            } else {
                                errorMessage = `注册失败: ${error.message}`;
                            }
                            this.$message.error(errorMessage);
                        })
                        .finally(() => {
                            this.registerLoading = false;
                        });
                }
            });
        }
    }
};
</script>

<style scoped>
.login-container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background-color: #f0f2f5;
    background-image: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiIHBhdHRlcm5UcmFuc2Zvcm09InJvdGF0ZSg0NSkiPjxyZWN0IGlkPSJwYXR0ZXJuLWJhY2tncm91bmQiIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9IiNmMGYyZjUiPjwvcmVjdD48cmVjdCBpZD0icmVjdDEiIHdpZHRoPSIxIiBoZWlnaHQ9IjEiIGZpbGw9IiNlNmU2ZTYiPjwvcmVjdD48cmVjdCBpZD0icmVjdDIiIHdpZHRoPSIyIiBoZWlnaHQ9IjIiIGZpbGw9IiNlNmU2ZTYiIHg9IjIwIiB5PSIyMCI+PC9yZWN0PjwvcGF0dGVybj48L2RlZnM+PHJlY3QgZmlsbD0idXJsKCNwYXR0ZXJuKSIgaGVpZ2h0PSIxMDAlIiB3aWR0aD0iMTAwJSI+PC9yZWN0Pjwvc3ZnPg==');
}

.login-box {
    width: 400px;
    padding: 40px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.login-title {
    text-align: center;
    margin-bottom: 30px;
    color: #409EFF;
    font-size: 24px;
}

.login-form {
    margin-top: 20px;
}

.login-button {
    width: 100%;
}

.forget-pwd {
    float: right;
    color: #409EFF;
    text-decoration: none;
}

.register-button {
    width: 100%;
    margin-top: 10px;
}
</style>
