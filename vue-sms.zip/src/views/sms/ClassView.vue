<template>
    <div>
        <el-card class="content-card">
            <div slot="header">
                <span>班级列表</span>
            </div>
            <div>
                这里是班级列表的内容
            </div>
        </el-card>
    </div>
</template>

<script>
export default {
    name: 'StudentView',
    data() {
        return {};
    }
};
</script>

<style scoped>
.student-container {
    height: 100%;
    background-color: #f0f2f5;
}

.main-container {
    height: 700px;
    border-radius: 4px;
    overflow: hidden;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.header {
    background-color: #409EFF;
    color: white;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 20px;
    font-size: 18px;
    font-weight: bold;
}

.aside {
    background-color: #fff;
    border-right: 1px solid #e6e6e6;
}

.main {
    background-color: #f0f2f5;
    padding: 20px;
}

.content-card {
    min-height: 300px;
}

.user-info {
    display: flex;
    align-items: center;
}

.menu {
    border-right: none;
}
</style>
