<template>
    <div>
        <el-card class="content-card">
            <div slot="header">
                <span>学生列表</span>
            </div>

            <!-- 搜索和操作区域 -->
            <div class="operation-container">
                <div class="search-area">
                    <el-input placeholder="请输入学生姓名" v-model="searchForm.name" clearable class="search-input">
                    </el-input>
                    <el-select v-model="searchForm.className" placeholder="班级" clearable class="search-select">
                        <el-option v-for="item in classOptions" :key="item.value" :label="item.label"
                            :value="item.value">
                        </el-option>
                    </el-select>
                    <el-select v-model="searchForm.gender" placeholder="性别" clearable class="search-select">
                        <el-option label="男" :value="1"></el-option>
                        <el-option label="女" :value="2"></el-option>
                        <el-option label="未知" :value="0"></el-option>
                    </el-select>
                    <el-button type="primary" icon="el-icon-search" @click="handleSearch">搜索</el-button>
                    <el-button icon="el-icon-refresh" @click="resetSearch">重置</el-button>
                </div>
                <div class="button-area">
                    <el-button type="primary" icon="el-icon-plus" @click="handleAdd">添加学生</el-button>
                    <el-button type="success" icon="el-icon-download" @click="exportData">导出</el-button>
                    <el-button type="warning" icon="el-icon-refresh" @click="getStudentList">刷新</el-button>
                </div>
            </div>

            <!-- 表格区域 -->
            <el-table :inline="true" :data="studentList" border style="width: 100%" v-loading="loading"
                :header-cell-style="{ background: '#f5f7fa', color: '#606266' }" height=60vh>
                <el-table-column type="index" label="序号" width="50" align="center"></el-table-column>
                <el-table-column prop="name" label="姓名" width="100"></el-table-column>
                <el-table-column prop="gender" label="性别" width="70">
                    <template slot-scope="scope">
                        <span v-if="scope.row.gender === 1">男</span>
                        <span v-else-if="scope.row.gender === 2">女</span>
                        <span v-else>未知</span>
                    </template>
                </el-table-column>
                <el-table-column prop="birthdate" label="出生日期" width="110"></el-table-column>
                <el-table-column prop="phone" label="联系电话" width="120"></el-table-column>
                <el-table-column prop="email" label="电子邮箱" width="180"></el-table-column>
                <el-table-column prop="className" label="所属班级" width="120"></el-table-column>
                <el-table-column prop="admissionDate" label="入学日期" width="110"></el-table-column>
                <el-table-column prop="address" label="家庭住址" align="center"></el-table-column>
                <el-table-column fixed="right" label="操作" width="180" align="center">
                    <template slot-scope="scope">
                        <el-button type="text" size="small" @click="handleEdit(scope.row)">编辑</el-button>
                        <el-button type="text" size="small" @click="handleDelete(scope.row)">删除</el-button>
                        <el-button type="text" size="small" @click="handleView(scope.row)">查看</el-button>
                    </template>
                </el-table-column>
            </el-table>

            <!-- 分页区域 -->
            <div class="pagination-container">
                <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                    :current-page="pagination.currentPage" :page-sizes="[10, 20, 50, 100]"
                    :page-size="pagination.pageSize" layout="total, sizes, prev, pager, next, jumper"
                    :total="pagination.total">
                </el-pagination>
            </div>

            <!-- 添加/编辑学生对话框 -->
            <el-dialog :title="dialogTitle" :visible.sync="dialogVisible" width="600px" @close="resetForm">
                <el-form :model="studentForm" :rules="rules" ref="studentForm" label-width="100px">
                    <el-form-item label="姓名" prop="name">
                        <el-input v-model="studentForm.name" placeholder="请输入姓名"></el-input>
                    </el-form-item>
                    <el-form-item label="性别" prop="gender">
                        <el-radio-group v-model="studentForm.gender">
                            <el-radio :label="1">男</el-radio>
                            <el-radio :label="2">女</el-radio>
                            <el-radio :label="0">未知</el-radio>
                        </el-radio-group>
                    </el-form-item>
                    <el-form-item label="出生日期" prop="birthdate">
                        <el-date-picker v-model="studentForm.birthdate" type="date" placeholder="选择日期"
                            style="width: 100%"></el-date-picker>
                    </el-form-item>
                    <el-form-item label="联系电话" prop="phone">
                        <el-input v-model="studentForm.phone" placeholder="请输入联系电话"></el-input>
                    </el-form-item>
                    <el-form-item label="电子邮箱" prop="email">
                        <el-input v-model="studentForm.email" placeholder="请输入电子邮箱"></el-input>
                    </el-form-item>
                    <el-form-item label="所属班级" prop="className">
                        <el-select v-model="studentForm.className" placeholder="请选择班级" style="width: 100%">
                            <el-option v-for="item in classOptions" :key="item.value" :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="入学日期" prop="admissionDate">
                        <el-date-picker v-model="studentForm.admissionDate" type="date" placeholder="选择日期"
                            style="width: 100%"></el-date-picker>
                    </el-form-item>
                    <el-form-item label="家庭住址" prop="address">
                        <el-input v-model="studentForm.address" type="textarea" :rows="2"
                            placeholder="请输入家庭住址"></el-input>
                    </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                    <el-button @click="dialogVisible = false">取 消</el-button>
                    <el-button type="primary" @click="submitForm">确 定</el-button>
                </div>
            </el-dialog>

            <!-- 查看学生详情对话框 -->
            <el-dialog title="学生详情" :visible.sync="viewDialogVisible" width="600px">
                <el-descriptions :column="2" border>
                    <el-descriptions-item label="姓名">{{ currentStudent.name }}</el-descriptions-item>
                    <el-descriptions-item label="性别">
                        <span v-if="currentStudent.gender === 1">男</span>
                        <span v-else-if="currentStudent.gender === 2">女</span>
                        <span v-else>未知</span>
                    </el-descriptions-item>
                    <el-descriptions-item label="出生日期">{{ currentStudent.birthdate }}</el-descriptions-item>
                    <el-descriptions-item label="联系电话">{{ currentStudent.phone }}</el-descriptions-item>
                    <el-descriptions-item label="电子邮箱">{{ currentStudent.email }}</el-descriptions-item>
                    <el-descriptions-item label="所属班级">{{ currentStudent.className }}</el-descriptions-item>
                    <el-descriptions-item label="入学日期">{{ currentStudent.admissionDate }}</el-descriptions-item>
                    <el-descriptions-item label="家庭住址" :span="2">{{ currentStudent.address }}</el-descriptions-item>
                </el-descriptions>
            </el-dialog>
        </el-card>
    </div>
</template>

<script>
import request from '@/utils/request'; // 替换为封装的请求工具

export default {
    name: 'StudentView',
    data() {
        return {
            // 表格加载状态
            loading: false,
            // 学生列表数据
            studentList: [],
            // 班级选项
            classOptions: [
                { value: '计科231', label: '计科231' },
                { value: '计科232', label: '计科232' },
                { value: '计科233', label: '计科233' },
                { value: '计科234', label: '计科234' },
                { value: '计科235', label: '计科235' },
                { value: '计科236', label: '计科236' }
            ],
            // 搜索表单
            searchForm: {
                name: '',
                className: '',
                gender: ''
            },
            // 分页信息
            pagination: {
                currentPage: 1,
                pageSize: 10,
                total: 0
            },
            // 对话框显示标志
            dialogVisible: false,
            // 查看详情对话框显示标志
            viewDialogVisible: false,
            // 对话框标题
            dialogTitle: '添加学生',
            // 当前操作的学生对象
            currentStudent: {},
            // 学生表单数据
            studentForm: {
                id: null,
                name: '',
                gender: 1,
                birthdate: '',
                phone: '',
                email: '',
                className: '',
                admissionDate: '',
                address: ''
            },
            // 表单验证规则
            rules: {
                name: [
                    { required: true, message: '请输入学生姓名', trigger: 'blur' },
                    { min: 2, max: 20, message: '长度在 2 到 20 个字符', trigger: 'blur' }
                ],
                gender: [
                    { required: true, message: '请选择性别', trigger: 'change' }
                ],
                phone: [
                    { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号码', trigger: 'blur' }
                ],
                email: [
                    { type: 'email', message: '请输入正确的邮箱地址', trigger: 'blur' }
                ],
                className: [
                    { required: true, message: '请选择班级', trigger: 'change' }
                ]
            }
        };
    },
    created() {
        this.getStudentList();
    },
    methods: {
        // 获取学生列表（调用真实API）
        getStudentList() {
            this.loading = true;

            // 构建请求参数
            const params = {
                name: this.searchForm.name || undefined,
                className: this.searchForm.className || undefined,
                gender: this.searchForm.gender !== '' ? this.searchForm.gender : undefined,
                page: this.pagination.currentPage,
                pageSize: this.pagination.pageSize
            };

            // 使用封装的request发起API请求，使用相对路径
            request.get('/admin/student/page', { params })
                .then(response => {
                    // 已在拦截器处理了非200状态，这里可以直接使用response
                    const { total, records } = response.data;
                    this.studentList = records;
                    this.pagination.total = total;
                })
                .catch(error => {
                    console.error('获取学生列表失败:', error);
                })
                .finally(() => {
                    this.loading = false;
                });
        },

        // 搜索
        handleSearch() {
            this.pagination.currentPage = 1;
            this.getStudentList();
        },

        // 重置搜索条件
        resetSearch() {
            this.searchForm = {
                name: '',
                className: '',
                gender: ''
            };
            this.handleSearch();
        },

        // 处理添加学生
        handleAdd() {
            this.dialogTitle = '添加学生';
            this.studentForm = {
                id: null,
                name: '',
                gender: 1,
                birthdate: '',
                phone: '',
                email: '',
                className: '',
                admissionDate: '',
                address: ''
            };
            this.dialogVisible = true;
        },

        // 处理编辑学生
        handleEdit(row) {
            this.dialogTitle = '编辑学生';
            // 深拷贝，避免直接修改表格数据
            this.studentForm = JSON.parse(JSON.stringify(row));
            this.dialogVisible = true;
        },

        // 处理查看学生详情
        handleView(row) {
            this.currentStudent = row;
            this.viewDialogVisible = true;
        },

        // 处理删除学生
        handleDelete(row) {
            this.$confirm('此操作将永久删除该学生信息, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                // 使用封装的request删除学生，使用相对路径
                request.delete(`/admin/student/${row.id}`)
                    .then(response => {
                        this.$message({
                            type: 'success',
                            message: '删除成功!'
                        });
                        // 重新获取列表
                        this.getStudentList();
                    })
                    .catch(error => {
                        console.error('删除学生失败:', error);
                    });
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });
            });
        },

        // 提交表单
        submitForm() {
            this.$refs.studentForm.validate((valid) => {
                if (valid) {
                    this.loading = true;

                    // 创建一个新对象用于提交
                    const formData = { ...this.studentForm };

                    // 格式化日期字段为YYYY-MM-DD格式的字符串
                    if (formData.birthdate) {
                        formData.birthdate = this.formatDate(formData.birthdate);
                    }
                    if (formData.admissionDate) {
                        formData.admissionDate = this.formatDate(formData.admissionDate);
                    }

                    if (this.studentForm.id) {
                        // 编辑操作，使用相对路径
                        request.put(`/admin/student/${this.studentForm.id}`, formData)
                            .then(response => {
                                this.$message({
                                    type: 'success',
                                    message: '更新成功!'
                                });
                                this.dialogVisible = false;
                                this.getStudentList();
                            })
                            .catch(error => {
                                console.error('更新学生信息失败:', error);
                            })
                            .finally(() => {
                                this.loading = false;
                            });
                    } else {
                        // 添加操作，使用相对路径
                        request.post('/admin/student/add', formData)
                            .then(response => {
                                this.$message({
                                    type: 'success',
                                    message: '添加成功!'
                                });
                                this.dialogVisible = false;
                                this.getStudentList();
                            })
                            .catch(error => {
                                console.error('添加学生失败:', error);
                            })
                            .finally(() => {
                                this.loading = false;
                            });
                    }
                } else {
                    console.log('error submit!!');
                    return false;
                }
            });
        },

        // 添加日期格式化函数
        formatDate(date) {
            if (!date) return '';

            // 判断是否已经是字符串格式
            if (typeof date === 'string') {
                // 如果已经是YYYY-MM-DD格式，直接返回
                if (/^\d{4}-\d{2}-\d{2}$/.test(date)) {
                    return date;
                }
            }

            // 将日期转换为JavaScript Date对象
            const dateObj = new Date(date);

            // 格式化为YYYY-MM-DD
            const year = dateObj.getFullYear();
            const month = String(dateObj.getMonth() + 1).padStart(2, '0');
            const day = String(dateObj.getDate()).padStart(2, '0');

            return `${year}-${month}-${day}`;
        },

        // 重置表单
        resetForm() {
            if (this.$refs.studentForm) {
                this.$refs.studentForm.resetFields();
            }
        },

        // 导出数据
        exportData() {
            this.$message.info('正在导出数据，请稍候...');
            this.loading = true;

            // 使用封装的request工具发送请求，使用相对路径
            // 设置responseType为blob以接收二进制文件数据
            request({
                url: '/admin/student/export',
                method: 'get',
                responseType: 'blob'
            })
                .then(response => {
                    // 获取文件数据，这里应该使用response.data而不是response，因为现在response是完整的axios响应对象
                    const blob = new Blob([response.data], {
                        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                    });

                    // 尝试从响应头获取文件名
                    let fileName = 'student_export.xlsx';
                    const disposition = response.headers['content-disposition'];
                    if (disposition && disposition.includes('filename=')) {
                        const filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
                        const matches = filenameRegex.exec(disposition);
                        if (matches != null && matches[1]) {
                            fileName = matches[1].replace(/['"]/g, '');
                        }
                    }

                    // 创建下载链接并触发下载
                    const link = document.createElement('a');
                    link.href = window.URL.createObjectURL(blob);
                    link.download = fileName;
                    link.style.display = 'none';
                    document.body.appendChild(link);
                    link.click();

                    // 释放URL对象
                    window.URL.revokeObjectURL(link.href);
                    document.body.removeChild(link);

                    this.$message.success('导出成功');
                })
                .catch(error => {
                    console.error('导出失败:', error);
                    this.$message.error('导出失败，请稍后重试');
                })
                .finally(() => {
                    this.loading = false;
                });
        },

        // 处理分页大小变化
        handleSizeChange(val) {
            this.pagination.pageSize = val;
            this.getStudentList();
        },

        // 处理页码变化
        handleCurrentChange(val) {
            this.pagination.currentPage = val;
            this.getStudentList();
        }
    }
};
</script>

<style scoped>
.content-card {
    min-height: 300px;
}

.operation-container {
    margin-bottom: 20px;
    display: flex;
    justify-content: space-between;
}

.search-area {
    display: flex;
    align-items: center;
}

.search-input {
    width: 200px;
    margin-right: 10px;
}

.search-select {
    width: 120px;
    margin-right: 10px;
}

.pagination-container {
    margin-top: 20px;
    text-align: right;
}
</style>