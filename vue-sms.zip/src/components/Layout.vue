<template>
    <div class="student-container">
        <el-container class="main-container" style="height: 95vh">
            <el-header class="header">
                <div class="logo">学生管理系统</div>
                <div class="user-info">
                    <el-dropdown @command="handleCommand">
                        <span class="user-dropdown-link">
                            <el-avatar size="small" icon="el-icon-user"></el-avatar>
                            <span style="margin-left: 10px">{{ username }}</span>
                            <i class="el-icon-arrow-down el-icon--right"></i>
                        </span>
                        <el-dropdown-menu slot="dropdown">
                            <el-dropdown-item command="userInfo"><i class="el-icon-user"></i> 个人信息</el-dropdown-item>
                            <el-dropdown-item command="changePwd"><i class="el-icon-key"></i> 修改密码</el-dropdown-item>
                            <el-dropdown-item divided command="logout"><i class="el-icon-switch-button"></i>
                                退出登录</el-dropdown-item>
                        </el-dropdown-menu>
                    </el-dropdown>
                </div>
            </el-header>
            <el-container>
                <el-aside width="230px" class="aside">
                    <el-menu :default-active="activeIndex" class="menu">
                        <el-menu-item index="1" @click="navigateTo('/student')">
                            <i class="el-icon-menu"></i>
                            <span>学生列表</span>
                        </el-menu-item>
                        <el-menu-item index="2" @click="navigateTo('/class')">
                            <i class="el-icon-document"></i>
                            <span>班级管理</span>
                        </el-menu-item>
                        <el-menu-item index="3" @click="navigateTo('/introduction')">
                            <i class="el-icon-setting"></i>
                            <span>系统介绍</span>
                        </el-menu-item>
                    </el-menu>
                </el-aside>
                <el-main class="main">
                    <router-view />
                </el-main>
            </el-container>
        </el-container>
    </div>
</template>

<script>
export default {
    name: 'Layout',
    data() {
        return {
            activeIndex: '1', // 默认激活第一个菜单
            username: '用户' // 默认用户名
        };
    },
    methods: {
        navigateTo(path) {
            this.$router.push(path);
        },
        setActiveMenu() {
            // 根据当前路径设置激活的菜单项
            const path = this.$route.path;
            if (path.includes('/student')) {
                this.activeIndex = '1';
            } else if (path.includes('/class')) {
                this.activeIndex = '2';
            } else if (path.includes('/introduction')) {
                this.activeIndex = '3';
            }
        },
        // 添加下拉菜单命令处理方法
        handleCommand(command) {
            if (command === 'logout') {
                this.logout();
            } else if (command === 'userInfo') {
                this.$message.info('个人信息功能开发中...');
            } else if (command === 'changePwd') {
                this.$message.info('修改密码功能开发中...');
            }
        },
        // 退出登录方法
        logout() {
            this.$confirm('确定要退出登录吗?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                // 清除登录状态和用户信息
                localStorage.removeItem('isLogin');
                localStorage.removeItem('token');
                localStorage.removeItem('userId');
                localStorage.removeItem('username');
                // 可以根据需要清除其他登录相关信息，但保留记住的用户名密码

                // 提示退出成功
                this.$message.success('退出登录成功');

                // 跳转到登录页
                this.$router.push('/login');
            }).catch(() => {
                // 取消退出操作
            });
        },
        // 获取用户信息
        getUserInfo() {
            const username = localStorage.getItem('username');
            if (username) {
                this.username = username;
            }
        }
    },
    watch: {
        $route() {
            // 路由变化时更新激活的菜单
            this.setActiveMenu();
        }
    },
    created() {
        // 组件创建时设置当前激活的菜单
        this.setActiveMenu();
        // 组件创建时获取用户信息
        this.getUserInfo();
    }
};
</script>

<style scoped>
.student-container {
    height: 100%;
    background-color: #f0f2f5;
}

.main-container {
    height: 700px;
    border-radius: 4px;
    overflow: hidden;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.header {
    background-color: #409EFF;
    color: white;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 20px;
    font-size: 18px;
    font-weight: bold;
}

.aside {
    background-color: #fff;
    border-right: 1px solid #e6e6e6;
}

.main {
    background-color: #f0f2f5;
    padding: 20px;
}

.content-card {
    min-height: 300px;
}

.user-info {
    display: flex;
    align-items: center;
}

.menu {
    border-right: none;
}

.el-menu-item {
    cursor: pointer;
}

.user-dropdown-link {
    display: flex;
    align-items: center;
    cursor: pointer;
    color: white;
}

.el-dropdown {
    color: white;
}
</style>
