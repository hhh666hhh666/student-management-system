import Vue from "vue";
import VueRouter from "vue-router";

Vue.use(VueRouter);

// 在路由配置文件中添加
import Layout from "@/components/Layout.vue";

const routes = [
    {
        path: "/login",
        name: "login",
        component: () => import("@/views/sms/LoginView.vue"),
        meta: { requiresAuth: false },
    },
    {
        path: "/",
        component: Layout,
        meta: { requiresAuth: true },
        children: [
            {
                path: "/student",
                name: "student",
                component: () => import("@/views/sms/StudentView.vue"),
            },
            {
                path: "/class",
                name: "class",
                component: () => import("@/views/sms/ClassView.vue"),
            },
            {
                path: "/introduction",
                name: "introduction",
                component: () => import("@/views/sms/IntroductionView.vue"),
            },
            {
                path: "",
                redirect: "/student",
            },
        ],
    },
];

const originalPush = VueRouter.prototype.push;
VueRouter.prototype.push = function push(location) {
    return originalPush.call(this, location).catch((err) => {
        if (err.name !== "NavigationDuplicated") throw err;
    });
};

const originalReplace = VueRouter.prototype.replace;
VueRouter.prototype.replace = function replace(location) {
    return originalReplace.call(this, location).catch((err) => {
        if (err.name !== "NavigationDuplicated") throw err;
    });
};

const router = new VueRouter({
    routes,
});

// 路由守卫，检查登录状态
router.beforeEach((to, from, next) => {
    const isLogin = localStorage.getItem("isLogin") === "true";

    if (to.matched.some((record) => record.meta.requiresAuth) && !isLogin) {
        // 如果路由需要认证且用户未登录，则重定向到登录页
        next({ path: "/login" });
    } else {
        // 如果用户已登录且访问登录页，则重定向到首页
        if (to.path === "/login" && isLogin) {
            next({ path: "/" });
        } else {
            next();
        }
    }
});

export default router;
