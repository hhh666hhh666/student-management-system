import axios from "axios";
import { Message } from "element-ui";
import router from "@/router";

// 设置API基础URL - 可以根据不同环境修改为不同的值
const BASE_API_URL = "http://192.168.88.130/api";

// 创建axios实例
const service = axios.create({
    baseURL: BASE_API_URL, // 设置基础URL
    timeout: 10000, // 请求超时时间
});

// 请求拦截器
service.interceptors.request.use(
    (config) => {
        console.log("发送请求:", config.url); // 添加调试日志

        // 不是登录请求时，添加token到请求头
        if (!config.url.includes("/admin/user/login")) {
            const token = localStorage.getItem("token");
            if (token) {
                config.headers["token"] = `${token}`;
            }
        }

        // 确保Content-Type正确设置
        if (config.method === "post" || config.method === "put") {
            config.headers["Content-Type"] = "application/json;charset=UTF-8";
        }

        return config;
    },
    (error) => {
        console.error("请求错误:", error);
        return Promise.reject(error);
    }
);

// 响应拦截器
service.interceptors.response.use(
    (response) => {
        console.log("收到响应:", response.config.url, response.data); // 添加调试日志

        // 如果是blob类型的响应（文件下载），直接返回response对象
        if (response.config.responseType === "blob") {
            return response;
        }

        const res = response.data;

        // 如果返回的状态码不是200，说明出错了
        if (res.code !== 200) {
            // 登录接口的错误处理交给login组件自己处理，避免重复提示
            if (!response.config.url.includes("/admin/user/login")) {
                Message({
                    message: res.message || "请求错误",
                    type: "error",
                    duration: 5 * 1000,
                });
            }

            // 401: 未授权 - token过期或者无效
            if (res.code === 401) {
                // 清除登录状态
                localStorage.removeItem("token");
                localStorage.removeItem("isLogin");

                // 跳转到登录页
                router.push("/login");
            }

            return Promise.reject(new Error(res.message || "请求错误"));
        } else {
            return res;
        }
    },
    (error) => {
        console.error("响应错误:", error);
        // 提供更详细的错误信息
        let errorMessage = "网络异常，请稍后再试";

        if (error.response) {
            // 服务器返回了错误状态码
            errorMessage = error.response.data.message || `请求失败: ${error.response.status}`;

            // 处理401未授权错误 - HTTP状态码
            if (error.response.status === 401) {
                // 清除登录状态
                localStorage.removeItem("token");
                localStorage.removeItem("isLogin");
                localStorage.removeItem("userId");
                localStorage.removeItem("username");

                // 显示未授权消息
                Message({
                    message: "登录已过期，请重新登录",
                    type: "warning",
                    duration: 3000,
                });

                // 延迟跳转到登录页，让用户能看到提示消息
                setTimeout(() => {
                    router.push("/login");
                }, 1000);
            }
        } else if (error.request) {
            // 请求发出但没有收到响应
            errorMessage = "服务器无响应，请检查后端服务是否正常运行";
        } else {
            // 请求配置出错
            errorMessage = error.message;
        }

        // 登录接口的错误处理交给login组件自己处理，避免重复提示
        if (!error.config || !error.config.url || !error.config.url.includes("/admin/user/login")) {
            Message({
                message: errorMessage,
                type: "error",
                duration: 5 * 1000,
            });
        }
        return Promise.reject(error);
    }
);

// 导出实例和基础URL
export default service;
export { BASE_API_URL };
