-- MySQL dump 10.13  Distrib 8.4.2, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sms
-- ------------------------------------------------------
-- Server version	8.4.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `student`
--

create schema sms;
use sms;

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(50) NOT NULL COMMENT '学生姓名',
  `gender` tinyint NOT NULL DEFAULT '0' COMMENT '性别(0未知 1男 2女)',
  `birthdate` date DEFAULT NULL COMMENT '出生日期',
  `phone` varchar(20) DEFAULT NULL COMMENT '联系电话',
  `email` varchar(100) DEFAULT NULL COMMENT '电子邮箱',
  `class_name` varchar(50) DEFAULT NULL COMMENT '所属班级',
  `admission_date` date DEFAULT NULL COMMENT '入学日期',
  `address` varchar(200) DEFAULT NULL COMMENT '家庭住址',
  `user_id` bigint NOT NULL COMMENT '所属用户ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`) USING BTREE,
  KEY `idx_class_name` (`class_name`) USING BTREE,
  KEY `idx_name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='学生表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (1,'张三',1,'2000-01-01','1234567890','zhangsan@example.com','计科234','2015-09-01','北京市朝阳区',1,'2025-03-22 17:47:21','2025-03-23 13:26:26'),(2,'李四',2,'2000-02-02','1234567891','lisi@example.com','计科234','2015-09-01','北京市海淀区',1,'2025-03-22 17:47:21','2025-03-23 13:26:26'),(3,'王五',1,'2000-03-03','1234567892','wangwu@example.com','计科234','2015-09-01','北京市东城区',1,'2025-03-22 17:47:21','2025-03-23 13:26:26'),(4,'赵六',2,'2000-04-04','1234567893','zhaoliu@example.com','计科234','2015-09-01','北京市西城区',1,'2025-03-22 17:47:21','2025-03-23 13:26:26'),(5,'孙七',1,'2000-05-05','1234567894','sunqi@example.com','计科234','2015-09-01','北京市丰台区',1,'2025-03-22 17:47:21','2025-03-23 13:26:26'),(6,'周八',2,'2000-06-06','1234567895','zhouba@example.com','计科233','2015-09-01','北京市石景山区',1,'2025-03-22 17:47:21','2025-03-23 13:28:15'),(7,'吴九',1,'2000-07-07','1234567896','wujiu@example.com','计科233','2015-09-01','北京市通州区',1,'2025-03-22 17:47:21','2025-03-23 13:28:15'),(8,'郑十',2,'2000-08-08','1234567897','zhengshi@example.com','计科233','2015-09-01','北京市顺义区',1,'2025-03-22 17:47:21','2025-03-23 13:28:15'),(9,'王十一',1,'2000-09-09','1234567898','wangshiyi@example.com','计科234','2015-09-01','北京市昌平区',1,'2025-03-22 17:47:21','2025-03-23 13:26:26'),(10,'李十二',2,'2000-10-10','1234567899','lishier@example.com','计科234','2015-09-01','北京市大兴区',1,'2025-03-22 17:47:21','2025-03-23 13:26:26'),(11,'赵十三',1,'2000-11-11','1234567800','zhaoshisan@example.com','计科234','2015-09-01','北京市房山区',1,'2025-03-22 17:47:21','2025-03-23 13:26:26'),(12,'孙十四',2,'2000-12-12','1234567801','sunshisi@example.com','计科234','2015-09-01','北京市门头沟区',1,'2025-03-22 17:47:21','2025-03-23 13:26:26'),(13,'周十五',1,'2001-01-01','1234567802','zhoushiwu@example.com','计科234','2015-09-01','北京市怀柔区',1,'2025-03-22 17:47:21','2025-03-23 13:26:26'),(14,'吴十六',2,'2001-02-02','1234567803','wushiliu@example.com','计科234','2015-09-01','北京市平谷区',1,'2025-03-22 17:47:21','2025-03-23 13:26:26'),(15,'郑十七',1,'2001-03-03','1234567804','zhengshqi@example.com','计科234','2015-09-01','北京市密云区',1,'2025-03-22 17:47:21','2025-03-23 13:26:26'),(16,'王十八',2,'2001-04-04','1234567805','wangshiba@example.com','计科234','2015-09-01','北京市延庆区',1,'2025-03-22 17:47:21','2025-03-23 13:26:26'),(17,'李十九',1,'2001-05-05','1234567806','lishijiu@example.com','计科234','2015-09-01','北京市朝阳区',1,'2025-03-22 17:47:21','2025-03-23 13:26:26'),(18,'赵二十',2,'2001-06-06','1234567807','zhaoershi@example.com','计科234','2015-09-01','北京市海淀区',1,'2025-03-22 17:47:21','2025-03-23 13:26:26'),(19,'张二一',1,'2000-01-01','0987654321','zhangeryi@example.com','计科233','2014-09-01','上海市黄浦区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(20,'李二二',2,'2000-02-02','0987654322','lierer@example.com','计科233','2014-09-01','上海市徐汇区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(21,'王二三',1,'2000-03-03','0987654323','wangersan@example.com','计科233','2014-09-01','上海市长宁区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(22,'赵二四',2,'2000-04-04','0987654324','zhaoersi@example.com','计科233','2014-09-01','上海市静安区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(23,'孙二五',1,'2000-05-05','0987654325','sunerwu@example.com','计科233','2014-09-01','上海市普陀区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(24,'周二六',2,'2000-06-06','0987654326','zhouerliu@example.com','计科233','2014-09-01','上海市虹口区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(25,'吴二七',1,'2000-07-07','0987654327','wuerqi@example.com','计科233','2014-09-01','上海市杨浦区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(26,'郑二八',2,'2000-08-08','0987654328','zhengerba@example.com','计科233','2014-09-01','上海市闵行区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(27,'王二九',1,'2000-09-09','0987654329','wangerjiu@example.com','计科233','2014-09-01','上海市宝山区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(28,'李三十',2,'2000-10-10','0987654330','lisanshi@example.com','计科233','2014-09-01','上海市嘉定区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(29,'赵三一',1,'2000-11-11','0987654331','zhaosanyi@example.com','计科233','2014-09-01','上海市浦东新区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(30,'孙三二',2,'2000-12-12','0987654332','sunsaner@example.com','计科233','2014-09-01','上海市金山区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(31,'周三三',1,'2001-01-01','0987654333','zhousansan@example.com','计科233','2014-09-01','上海市松江区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(32,'吴三四',2,'2001-02-02','0987654334','wusansi@example.com','计科233','2014-09-01','上海市青浦区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(33,'郑三五',1,'2001-03-03','0987654335','zhengsanwu@example.com','计科233','2014-09-01','上海市奉贤区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(34,'王三六',2,'2001-04-04','0987654336','wangsanliu@example.com','计科233','2014-09-01','上海市崇明区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(35,'李三七',1,'2001-05-05','0987654337','lisanqi@example.com','计科233','2014-09-01','上海市黄浦区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(36,'赵三八',2,'2001-06-06','0987654338','zhaosanba@example.com','计科233','2014-09-01','上海市徐汇区',2,'2025-03-22 17:47:21','2025-03-23 13:26:36'),(37,'张三九',1,'2000-01-01','1122334455','zhangsanjiu@example.com','计科232','2013-09-01','广州市天河区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(38,'李四十',2,'2000-02-02','1122334456','lisishi@example.com','计科232','2013-09-01','广州市越秀区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(39,'王四一',1,'2000-03-03','1122334457','wangsiyi@example.com','计科232','2013-09-01','广州市海珠区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(40,'赵四二',2,'2000-04-04','1122334458','zhaosier@example.com','计科232','2013-09-01','广州市荔湾区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(41,'孙四三',1,'2000-05-05','1122334459','sunsisan@example.com','计科232','2013-09-01','广州市白云区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(42,'周四四',2,'2000-06-06','1122334460','zhousisi@example.com','计科232','2013-09-01','广州市黄埔区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(43,'吴四五',1,'2000-07-07','1122334461','wusiwu@example.com','计科232','2013-09-01','广州市番禺区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(44,'郑四六',2,'2000-08-08','1122334462','zhengsiliu@example.com','计科232','2013-09-01','广州市花都区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(45,'王四七',1,'2000-09-09','1122334463','wangsqi@example.com','计科232','2013-09-01','广州市南沙区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(46,'李四八',2,'2000-10-10','1122334464','lisiba@example.com','计科232','2013-09-01','广州市从化区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(47,'赵四九',1,'2000-11-11','1122334465','zhaosijiu@example.com','计科232','2013-09-01','广州市增城区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(48,'孙五十',2,'2000-12-12','1122334466','sunwushi@example.com','计科232','2013-09-01','广州市天河区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(49,'周五十一',1,'2001-01-01','1122334467','zhouwuyi@example.com','计科232','2013-09-01','广州市越秀区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(50,'吴五十二',2,'2001-02-02','1122334468','wuwuer@example.com','计科232','2013-09-01','广州市海珠区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(51,'郑五十三',1,'2001-03-03','1122334469','zhengwusan@example.com','计科232','2013-09-01','广州市荔湾区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(52,'王五十四',2,'2001-04-04','1122334470','wangwusi@example.com','计科232','2013-09-01','广州市白云区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(53,'李五十五',1,'2001-05-05','1122334471','liwuwu@example.com','计科232','2013-09-01','广州市黄埔区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(54,'赵五十六',2,'2001-06-06','1122334472','zhaowuliu@example.com','计科232','2013-09-01','广州市番禺区',3,'2025-03-22 17:47:21','2025-03-23 13:26:54'),(56,'lzh1',1,'2025-03-24','13412312345','lzh.h@qq.com','计科234','2023-09-01','地球',1,'2025-03-23 14:35:04','2025-03-25 14:15:35'),(57,'张三',1,'2025-03-01','13411100001','','计科234','2025-03-01','111',4,'2025-03-23 17:24:44','2025-03-23 17:24:44');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(100) NOT NULL COMMENT '加密密码',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_username` (`username`) USING BTREE,
  KEY `idx_create_time` (`create_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'user1','e10adc3949ba59abbe56e057f20f883e','user1@example.com','1234567890','2025-03-22 17:43:04','2025-03-23 01:29:31'),(2,'user2','123456','user2@example.com','0987654321','2025-03-22 17:43:04','2025-03-22 17:43:04'),(3,'user3','123456','user3@example.com','1122334455','2025-03-22 17:43:04','2025-03-22 17:43:04'),(4,'user','e10adc3949ba59abbe56e057f20f883e',NULL,NULL,'2025-03-23 17:23:02','2025-03-23 17:23:02');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-25 23:03:32
